import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Float64MultiArray
import math

class MotionPlanner(Node):

    def __init__(self):
        super().__init__('motion_planner')
        
        self.subscription_trajectory = self.create_subscription(Float64MultiArray, '/trajectory', self.trajectory_callback, 10)
        self.subscription_odom = self.create_subscription(Odometry, '/odom', self.odom_callback, 10)
        self.subscription_target_pose = self.create_subscription(Float64MultiArray, '/target_pose', self.target_pose_callback, 10)
        self.publisher_start_goal = self.create_publisher(Float64MultiArray, '/start_goal', 10)
        self.publisher_reference_pose = self.create_publisher(Float64MultiArray, '/reference_pose', 10)

        self.current_position = [0.0, 0.0]
        self.target_position = [0.0, 0.0]
        self.trajectory = []
        self.current_trajectory_index = 0

    def target_pose_callback(self, msg):
        self.target_position = (msg.data[0], msg.data[1])
        self.get_logger().info(f'Received new target position: {self.target_position}')
        self.send_start_goal()

    def odom_callback(self, msg):
        self.current_position = (msg.pose.pose.position.x, msg.pose.pose.position.y)
        self.process_trajectory()

    def trajectory_callback(self, msg):
        self.trajectory = [(msg.data[i], msg.data[i+1]) for i in range(0, len(msg.data), 2)]
        self.get_logger().info(f'Parsed trajectory: {self.trajectory}')
        self.current_trajectory_index = 0
        self.send_next_reference_pose()

    def send_start_goal(self):
        start_goal_msg = Float64MultiArray()
        start_goal_msg.data = [self.current_position[0], self.current_position[1], self.target_position[0], self.target_position[1]]
        self.publisher_start_goal.publish(start_goal_msg)
        self.get_logger().info(f'Sent start goal: {start_goal_msg.data}')

    def send_next_reference_pose(self):
        if self.trajectory and self.current_trajectory_index < len(self.trajectory):
            next_pose = Float64MultiArray()
            next_pose.data = [
                self.trajectory[self.current_trajectory_index][0],
                self.trajectory[self.current_trajectory_index][1]
            ]
            self.publisher_reference_pose.publish(next_pose)
            self.get_logger().info(f'Sent reference pose: {next_pose.data[0]}, {next_pose.data[1]}]')
        else:
            self.get_logger().info("All waypoints reached, waiting for new target...")

    def process_trajectory(self):
        if not self.trajectory or self.current_trajectory_index >= len(self.trajectory):
            return

        next_position = self.trajectory[self.current_trajectory_index]
        if self.is_close_to(next_position):
            self.current_trajectory_index += 1
            if self.current_trajectory_index < len(self.trajectory):
                self.send_next_reference_pose()
            else:
                self.get_logger().info("Reached final waypoint, waiting for new target...")

    def is_close_to(self, position):
        distance = math.sqrt((self.current_position[0] - position[0]) ** 2 + (self.current_position[1] - position[1]) ** 2)
        return distance < 0.1  # Threshold for "very close"

def main(args=None):
    rclpy.init(args=args)
    motion_planner = MotionPlanner()
    rclpy.spin(motion_planner)
    motion_planner.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
