import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from math import atan2, sqrt, pi
from std_msgs.msg import Float64MultiArray

class PIDController(Node):
    def __init__(self):
        super().__init__('PID_Controller')
        self.declare_parameters(
            namespace='',
            parameters=[
                ('Kp_linear', 0.5),  # Adjusted gain
                ('Ki_linear', 0.0),  # No integral action initially
                ('Kd_linear', 0.1),  # Adjusted gain
                ('Kp_angular', 2.0), # Adjusted gain
                ('Ki_angular', 0.0), # No integral action initially
                ('Kd_angular', 0.1)  # Adjusted gain
            ]
        )
        self.x_goal = 0.0
        self.y_goal = 0.0
        self.current_x = 0.0
        self.current_y = 0.0
        self.current_theta = 0.0
        self.error_position = 0.0
        self.error_angle = 0.0
        self.prev_error_angle = 0.0
        self.integral_error_angle = 0.0
        self.prev_error_position = 0.0
        self.integral_error_position = 0.0
        self.get_parameters()
        self.create_subscription(Float64MultiArray, '/reference_pose', self.reference_pose_callback, 10)
        self.create_subscription(Odometry, '/odom', self.pose_callback, 10)
        self.vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.waypoints = []

    def get_parameters(self):
        self.Kp_linear = self.get_parameter('Kp_linear').value
        self.Ki_linear = self.get_parameter('Ki_linear').value
        self.Kd_linear = self.get_parameter('Kd_linear').value
        self.Kp_angular = self.get_parameter('Kp_angular').value
        self.Ki_angular = self.get_parameter('Ki_angular').value
        self.Kd_angular = self.get_parameter('Kd_angular').value

    def reference_pose_callback(self, msg):
        self.waypoints.append((msg.data[0], msg.data[1]))
        if len(self.waypoints) == 1:  # Only start moving to goal if this is the first waypoint
            self.x_goal, self.y_goal = self.waypoints[0]
            self.get_logger().info(f'Received new goal: ({self.x_goal}, {self.y_goal})')

            self.integral_error_position = 0.0
            self.prev_error_position = 0.0
            self.integral_error_angle = 0.0
            self.prev_error_angle = 0.0

    def pose_callback(self, data: Odometry):
        self.current_x = data.pose.pose.position.x
        self.current_y = data.pose.pose.position.y
        quaternion = (
            data.pose.pose.orientation.x,
            data.pose.pose.orientation.y,
            data.pose.pose.orientation.z,
            data.pose.pose.orientation.w
        )
        siny_cosp = 2.0 * (quaternion[3] * quaternion[2] + quaternion[0] * quaternion[1])
        cosy_cosp = 1.0 - 2.0 * (quaternion[1] * quaternion[1] + quaternion[2] * quaternion[2])
        self.current_theta = atan2(siny_cosp, cosy_cosp)
        self.move_to_goal()

    def move_to_goal(self):
        if not self.waypoints:
            return

        self.error_position = sqrt((self.x_goal - self.current_x)**2 + (self.y_goal - self.current_y)**2)
        self.error_angle = atan2((self.y_goal - self.current_y), (self.x_goal - self.current_x)) - self.current_theta

        while self.error_angle > pi:
            self.error_angle -= 2 * pi
        while self.error_angle < -pi:
            self.error_angle += 2 * pi

        self.integral_error_position += self.error_position
        derivative_error_position = self.error_position - self.prev_error_position
        control_output_position = (self.Kp_linear * self.error_position +
                                   self.Ki_linear * self.integral_error_position +
                                   self.Kd_linear * derivative_error_position)

        self.integral_error_angle += self.error_angle
        derivative_error_angle = self.error_angle - self.prev_error_angle
        control_output_angle = (self.Kp_angular * self.error_angle +
                                self.Ki_angular * self.integral_error_angle +
                                self.Kd_angular * derivative_error_angle)

        move = Twist()
        if self.error_position < 0.08:
            move.linear.x = 0.0
            move.angular.z = 0.0
        else:
            move.linear.x = min(control_output_position, 0.3)  # Lower maximum speed
            move.angular.z = control_output_angle

        self.vel_pub.publish(move)

        self.prev_error_position = self.error_position
        self.prev_error_angle = self.error_angle

        if self.error_position < 0.08:
            self.get_logger().info("Waypoint reached")
            if len(self.waypoints) > 1:
                self.waypoints.pop(0)
                self.x_goal, self.y_goal = self.waypoints[0]
                self.get_logger().info(f'Moving to next waypoint: ({self.x_goal}, {self.y_goal})')
            else:
                self.waypoints.pop(0)
                self.get_logger().info("Final goal reached, waiting for new waypoints...")

def main(args=None):
    rclpy.init(args=args)
    pid_controller = PIDController()
    try:
        rclpy.spin(pid_controller)
    except KeyboardInterrupt:
        pass
    finally:
        pid_controller.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
